Modules used (if not already on computer):
pygame, random, os, time, re, stopwatch

Music (https://timbeek.itch.io/royalty-free-music-pack) by timbeek.com (https://timbeek.itch.io/) (notably song.wav, and songPaused.wav, originally titled '8-Bit DNA Loop' and 'Try and Solve This', respectively), licensed under CC BY 4.0

Sound effect 'victory.wav', (https://freesound.org/people/maxmakessounds/sounds/353546/) originally titled 'success.wav' from freesound.org by user maxmakessounds (https://freesound.org/people/maxmakessounds/), licensed under CC BY 3.0.

No changes were made to any of the tracks.

https://creativecommons.org/licenses/by/3.0/legalcode

https://creativecommons.org/licenses/by/4.0/legalcode