import pygame
import random
import os
import time
import re

from stopwatch import Stopwatch

stopwatch = Stopwatch()

class inputBox(object):
    def __init__(self):
        self.rect = pygame.Rect(60,150,500,60)
        self.smallerRect = pygame.Rect(65,155,490,50)
        self.font = pygame.font.SysFont('Corbel',20)
        self.text = "Enter here."
        self.colourBig = (255,255,255)
        self.colourSmall = (0,0,0)

class menuButtons(object):
    def __init__(self):
        moving = 280
        ymoving = 435
        self.rect = pygame.Rect(480,635,120,30)
        self.smallerRect = pygame.Rect(485,640,110,20)
        self.colourBig = (255,255,255)
        self.colourSmall = (0,0,0)
        self.fontSize = 20
        self.font = pygame.font.SysFont('Corbel',self.fontSize)
        self.text = "blank"
        self.textPos = (520,640)

class hintPeg(object):
    def __init__(self):
        self.rect = pygame.Rect(100,10,10,10)
        self.colour = "black"
        self.rgb = (0,0,0)

class fixedPeg(object):
    def __init__(self):
        self.rect = pygame.Rect(10,10,50,50)
        self.colour = "white"
        self.rgb = (255,255,255)

class guessingPeg(object):
    def __init__(self):
        self.rect = pygame.Rect(600,10,50,50)
        self.colour = "red"

class inputPeg(object):
    def __init__(self):
        self.rect = pygame.Rect(600,10,50,50)

def check_last_score(high_score):
    try:
        save_file = open("leaderboard.txt","r")
        listOfScores = save_file.readlines()
        listOfScoresOrig = listOfScores.copy()
        l1 = listOfScoresOrig[0]
        l2 = listOfScoresOrig[1]
        

        for x in range(len(listOfScores)):
            listOfScores[x] = listOfScores[x].replace("\n","")
            listOfScores[x] = listOfScores[x].split(": ")
        
        l3 = listOfScores[2]

        if int(l3[1]) >= high_score:
            leaderboardEntered = False
        else:
            leaderboardEntered = True
        save_file.close()
    except IOError:
        print("Unable to save.")
    return leaderboardEntered


#here - issue with saving high scores you probably remembre.yeah        
def save_high_score(high_score,name):
    try:
        save_file = open("leaderboard.txt","r")
        listOfScores = save_file.readlines()
        listOfScoresOrig = listOfScores.copy()
        l1 = listOfScoresOrig[0]
        l2 = listOfScoresOrig[1]
        l3 = listOfScoresOrig[2]
        
        for x in range(len(listOfScores)):
            listOfScores[x] = listOfScores[x].replace("\n","")
            listOfScores[x] = listOfScores[x].split(": ")

        #1st pos
        counter = 0
        your_place = 0
        for x in listOfScores:
            x[1] = int(x[1])
            compared = x[1]
            if compared < high_score:
                smallestBiggerThanFound = True
                break
            else:
                counter += 1
            
        your_place = counter
        newList = []
        if your_place != 2:
            stringYours = name + ": " + str(high_score) + "\n"
        else:
            stringYours = name + ": " + str(high_score)
        
        #newList[your_place] = stringYours
        

        if your_place == 0:
            newList = [stringYours,l1,l2]
        elif your_place == 1:
            newList = [l1,stringYours,l2]
        else:
            newList = [l1,l2,stringYours]

        

        checker = newList[2]
        if checker[-1] == "\n":
            newList[2] = newList[2].replace("\n","")

        for i in range(2):
            checker = newList[i]
            if checker[-1] != "\n":
                newList[i] = newList[i] + "\n"
            
        
        save_file.close()
        save_file = open("leaderboard.txt","w")
        for x in newList:
            save_file.write(x)
        save_file.close()
    except IOError:
        print("Unable to save.")

#e.g.:
#save_high_score(40000000000,"Leom eom")

def load_high_score():
    high_score = 0
    try:
        save_file = open("save.txt","r")
        high_score = int(save_file.read())
        save_file.close()
    except IOError:
        print("No high score available.")
    except ValueError:
        print("File error. High score set to 0.")
    return high_score


def load_leaderboard():
    global leaderboard
    try:
        with open("leaderboard.txt","r") as leaders:
            leaderboard = []
            for line in leaders:
                leaderboard.append(line.strip())
        leaders.close()
    except IOError:
        print("No leaderboard available.")
    except ValueError:
        print("File error. No leaderboard was loaded.")

def text_objects(text,font):
    textSurface = font.render(text, True, (255,255,255))
    return textSurface, textSurface.get_rect()

def message_display(text, top, left, size):
    #set font & size
    my_text = pygame.font.Font('freesansbold.ttf',size)
    #create text objects
    text_surface,text_rect = text_objects(text, my_text)
    #set where the text appears on the screen
    text_rect.center = ((top),(left))
    screen.blit(text_surface, text_rect)

def colourToRgb(colourName):
    rgb = colours[colourName]
    return rgb

#countlimit = column, guessNumber = row
def guessPosRectGetter(countLimit,guessNumber):
    rectPosX = countLimit-1
    rectPosY = guessNumber-1
    newRectPos = [rectPosX,rectPosY]
    return newRectPos


def colourOfEnteredGuessChanger(countLimit,guessNumber,guessColour,listOfGuesses):
    poses = guessPosRectGetter(countLimit,guessNumber)
    row = poses[1]
    column = poses[0]
    enumerator = 0
    for x in range(0,len(listOfGuesses)):
        row2 = listOfGuesses[x]
        for y in range(0,len(row2)):
            #when the specific position you want to change is reached(based on countLimit & guessnumber)
            #it changes that position's colour
            #note that the .colour only relates to guessList, a plaintext-ish version of the guesses
            #the .rgb actually changes it
            if x == row and y == column:
                row2[y].colour = guessColour
                row2[y].rgb = colourToRgb(guessColour)
            else:
                pass
    return listOfGuesses

#guessNumber = row
def colourHintPegChanger(guessNumber,coloursList,hintSq):
    row = hintSq[guessNumber]
    for y in range(4):
        row[y].colour = coloursList[y]
        if row[y].colour == "red":
            row[y].rgb = (255,0,0)
        elif row[y].colour == "white":
            row[y].rgb = (255,255,255)
        elif row[y].colour == "black":
            row[y].rgb = (50,50,50)
        else:
            print("eror")
    for x in row:
        return hintSq

#this makes the pegs that show what you've already guessed, rows    
def listMaker4(prevY):
    list4 = []
    quantifier = 0
    for i in range(4):
        list4.append(fixedPeg())
        list4[-1].rect = pygame.Rect(20+quantifier,10+prevY,50,50)
        quantifier += 70
    return list4

#the same as above, but it adds those rows into columns
def listMaker10():
    list10 = []
    prevY = 10
    for i in range(10):
        toAppend = listMaker4(prevY)
        list10.append(toAppend)
        prevY += 70
    return list10

#this makes small 4-hint squares, in their groups
def fourSquares4s(prevY):
    list4 = []
    quantifier = 0
    secondaryY = 15
    for i in range(3):
       list4.append(hintPeg())
       list4[-1].rect = pygame.Rect(300+quantifier,20+prevY,10,10)            
       quantifier += 20
       if i >= 2:
           del list4[-1]
           quantifier = 0
           list4.append(hintPeg())
           list4[-1].rect = pygame.Rect(300+quantifier,20+prevY+secondaryY,10,10)
           quantifier += 20
       else:
            pass

    list4.append(hintPeg())
    list4[-1].rect = pygame.Rect(300+quantifier,20+prevY+secondaryY,10,10)

    return list4

#this makes the rows of 4-hint squares
def fourSquaresForHintsMaker10s():
    list10 = []
    prevY = 10
    smallerGap = 5
    for i in range(10):
        toAppend = fourSquares4s(prevY)
        list10.append(toAppend)
        prevY += 70
    return list10

def PegValidity(colour,position,trueGuess):
    yourPeg = 'black'
    for x in range(4):
        if colour == trueGuess[x] and position == x:
            yourPeg = 'red'
            break
        elif colour == trueGuess[x]:
            yourPeg = 'white'
            break
    #print(yourPeg)
    return yourPeg

def guessChecker(guesses,trueGuess):
    
    listRedWhiteBlackPegs = []
    #for each guess in list guesses
    for i in range(0,len(guesses)):
        sublist = []
        yourGuess = guesses[i]
        #for each colour in guess
        for j in range(4):
            partToBePassed = yourGuess[j]
            colour = partToBePassed
            position = j
            currentGuess = i+1
            sublist.append(PegValidity(colour,position,trueGuess))
            
        listRedWhiteBlackPegs.append(sublist)
    
    return listRedWhiteBlackPegs

#used as in:print(guessChecker(guesses,trueGuess))

def checkForWin(guess, trueGuess):
    if guess == trueGuess:
        win = True
        running = True
        return win
    else:
        win = False
        return win

banner = pygame.image.load(r'banner.png')
#colours list
redRGB = (255,0,0)
orangeRGB = (255,165,0)
yellowRGB = (255,255,0)
greenRGB = (0,255,0)
#blueRGB = (0,0,255)
blueRGB = (0,255,255)
#indigoRGB = (75,0,130)
indigoRGB = (0,31,255)
violetRGB = (206,0,255)
colours = {
    "red":redRGB,
    "orange":orangeRGB,
    "yellow":yellowRGB,
    "green":greenRGB,
    "blue":blueRGB,
    "indigo":indigoRGB,
    "violet":violetRGB,
    "white":(255,255,255),
    "black":(0,0,0)
    }

#sets the icon
programIcon = pygame.image.load('icon.png')
pygame.display.set_icon(programIcon)

colourList = ["red","orange","yellow","green","blue","indigo","violet"]

#e.g. to change :
listOfGuesses = listMaker10()
#listOfGuesses = colourOfEnteredGuessChanger(1,1,"red",listOfGuesses)
hintSq = fourSquaresForHintsMaker10s()
'''for x in hintSq:
    for y in x:
        print(y.rect)'''


def generateRandomColourSequence():
    colourSequence = []
    for x in range(0,4):
        index = random.randint(0,6)
        colour = colourList[index]
        colourSequence.append(colour)
    return colourSequence

#the message_display stuff is borrowed from the previous pygame project :)
def text_objects(text,font):
    textSurface = font.render(text, True, (255,255,255))
    return textSurface, textSurface.get_rect()

def message_display(text, top, left, size):
    #set font & size
    my_text = pygame.font.Font('freesansbold.ttf',size)
    #create text objects
    text_surface,text_rect = text_objects(text, my_text)
    #set where the text appears on the screen
    text_rect.center = ((top),(left))
    screen.blit(text_surface, text_rect)

#e.g. test
#test = ["black","red","black","black"]
#sfuck = colourHintPegChanger(5,test,fuck)


#makes a random colour
randomColour = generateRandomColourSequence()
color = colourToRgb("red")

#init
os.environ["SDL_VIDEO_CENTERED"] = "1"
pygame.init()

pygame.display.set_caption("Mastermind")
width = 620
height = 720
screen = pygame.display.set_mode((width,height))

#creates instances of the colours you can use to guess
r = guessingPeg()
o = guessingPeg()
y = guessingPeg()
g = guessingPeg()
b = guessingPeg()
i = guessingPeg()
v = guessingPeg()

win = False
lose = False
lastGuessWin = False
interfacePegs = [r,o,y,g,b,i,v]
#that was just a test peg below :p
yourPeg = guessingPeg()

#fonts & time
clock = pygame.time.Clock()
font = pygame.font.Font(None,35)
font_color = pygame.Color('white')

fontSmaller = pygame.font.Font(None,25)
fontSmallerColour = pygame.Color('white')

passed_time = 0
timer_started = True


inputtedPeg = inputPeg()
quantifier = 10
guessList = [[],[],[],[],[],[],[],[],[],[]]
guessNumber = 0
countLimit = 0
winningGuess = ["red","red","red","red"]
quantifier = 0
quantifierY = 0
slotPos = 0


aPeg = fixedPeg()
a = fixedPeg()
b = fixedPeg()
c = fixedPeg()
d = fixedPeg()

list10 = []
list4 = []

#here

#menu
#i decided to do this like this because i didnt feel like writing another series of loops
#also theyre all pretty different so
#i think it was worth defining these buttons like this

winLostSeq = False
leaderboardEntered = False
start_time = 0
buttonQuit = menuButtons()
buttonQuit.text = "Quit"

buttonStartOrPause = menuButtons()
buttonStartOrPause.text = "Start"
buttonStartOrPause.rect = pygame.Rect(480,635-50,120,30)
buttonStartOrPause.smallerRect = pygame.Rect(485,640-50,110,20)
buttonStartOrPause.textPos = (520,640-50)

buttonMenu = menuButtons()
buttonMenu.text = "Main Menu"
buttonMenu.rect = pygame.Rect(480,635-100,120,30)
buttonMenu.smallerRect = pygame.Rect(485,640-100,110,20)
buttonMenu.textPos = (495,640-100)

buttonSaveLoad = menuButtons()
buttonSaveLoad.text =  "Save/Load"
buttonSaveLoad.rect = pygame.Rect(480,635-150,120,30)
buttonSaveLoad.smallerRect = pygame.Rect(485,640-150,110,20)
buttonSaveLoad.textPos = (495,640-150)

listOfButtons = [buttonQuit,buttonStartOrPause,buttonMenu]

miniSave = menuButtons()
miniSave.text = "Save"
miniSave.rect = pygame.Rect(400,156,140,35)
miniSave.smallerRect = pygame.Rect(400+5,156+5,130,25)
miniSave.textPos = (470,174)
miniSave.fontSize = 20

miniLoad = menuButtons()
miniLoad.text = "Load"
miniLoad.rect = pygame.Rect(400,156+50,140,35)
miniLoad.smallerRect = pygame.Rect(400+5,156+5+50,130,25)
miniLoad.textPos = (470,174+50)
miniLoad.fontSize = 20

buttonSlot1 = menuButtons()
buttonSlot1.text = "Slot 1"
buttonSlot1.rect = pygame.Rect(48,156,280,80)
buttonSlot1.smallerRect = pygame.Rect(48+5,156+5,270,70)
buttonSlot1.textPos = (195,195)
buttonSlot1.fontSize = 50

buttonSlot2 = menuButtons()
buttonSlot2.text = "Slot 2"
buttonSlot2.rect = pygame.Rect(48,156+100,280,80)
buttonSlot2.smallerRect = pygame.Rect(48+5,156+5+100,270,70)
buttonSlot2.textPos = (195,195+100)
buttonSlot2.fontSize = 50

buttonSlot3 = menuButtons()
buttonSlot3.text = "Slot 3"
buttonSlot3.rect = pygame.Rect(48,156+200,280,80)
buttonSlot3.smallerRect = pygame.Rect(48+5,156+5+200,270,70)
buttonSlot3.textPos = (195,195+200)
buttonSlot3.fontSize = 50

slotButtons = [buttonSlot1,buttonSlot2,buttonSlot3]
saveLoadMiniButtons = [miniSave,miniLoad]

paused = True

#sorting out the interface pegs(in terms of rect)
for i in range(7):
    interfacePegs[i].rect = pygame.Rect(540,10+quantifier,50,50)
    quantifier += 75
    interfacePegs[i].colour = colourList[i]

running = True
winningGuess = generateRandomColourSequence()
newTime = 0
oldTime = 0
sortedOut = False
testing = False
firstRun = True
elapsed = 0
passedTime = 0
timePaused = 0

def save_game(guesses,trueGuess,guessNumber,countLimit,slot,startTime):
    yourSave = "save_slot"+str(slot)+".txt"


    try:
        save_file = open(yourSave,"w")
        enumerator = 0
        #making it able to be saved in a txt file and manipulated later
        for x in guesses:
            for y in x:
                if enumerator == 3:
                    string = str(y.colour)
                    if string == "white":
                        string = ""
                else:
                    string = str(y.colour)+","
                    if string == "white,":
                        string = ","
                save_file.write(string)
                enumerator += 1
            string = "\n"
            save_file.write(string)
            enumerator = 0
        a = str(trueGuess)+"\n"
        b = str(guessNumber)+"\n"
        c = str(countLimit)+"\n"
        d = str(slot)+"\n"
        e = str(startTime)+"\n"

        #this is out of order because it didn't work if it wasn't in this order
        save_file.write(b)
        save_file.write(c)
        save_file.write(e)
        save_file.write(a)
        save_file.write(d)
        save_file.close()
    except IOError:
        print("Unable to save.")
        

'''reading a file. this is the one that worked.
this one basically spits out variables which then have to be reflected on the screen
based on what was in the save_slot text file'''
def makeItLoad(slot):
    colourSequence10s = []
    textSlot = str(slot)
    yourSave = "save_slot"+textSlot+".txt"
    save_file = open(yourSave,"r")
    for i in range(10):
        a = save_file.readline()
        a = a.split(",")
        for i in range(len(a)):
            a[i] = a[i].strip("\n")
        colourSequence10s.append(a)
    makeItLoadColours = colourSequence10s
    countLimit = save_file.readline()
    guessNumber = save_file.readline()
    start_time = save_file.readline()
    winningGuess = save_file.readline()
    winningGuess = winningGuess.strip("[]\n")
    winningGuess = winningGuess.replace("'","")
    winningGuess = winningGuess.split(", ")
    slot = save_file.readline()
    save_file.close()
    listy = [colourSequence10s,countLimit,guessNumber,start_time,winningGuess,slot]
    return listy


'''basically to explain all these extra subroutines
the previous ones just changed it for that specific value, e.g. red in the 2nd row and 2nd part of that row
but they just. didnt work
so i made new ones and these work when loading
'''
def guessListChanger(newList,blankList):
    for x in range(9):
        rowX = newList[x]
        rowBX = blankList[x]
        for y in range(4):
            if rowX[y] == "":
                break
            else:
               rowBX.append(rowX[y])
    return blankList

#guesslist = colours, listofguesses = rects and stuff
def loadUpdater(guessList,listOfGuesses,countLimit,guessNumber):
    for x in range(9):
        rowAX = guessList[x]
        rowBX = listOfGuesses[x]
        for y in range(4):
            if y == len(rowAX):
                break
            rowBX[y].colour = rowAX[y]
            rowBX[y].rgb = colourToRgb(rowAX[y])


def loadHintPegChecker(guessList,trueGuess,guessNumber,hintSq,countLimit):
    for j in range(guessNumber):
        list3 = ["","","",""]
        valList = list3
        row = guessList[j]
        list1 = row
        list2 = trueGuess

        for x in range(4):
            for y in range(4):
                pos1 = y
                pos2 = x
                if list1[y] == list2[x] and y == x:
                    list3[y] = "red"
                elif list1[y] == list2[x] and y != x:
                    if list3[y] != "red":
                        list3[y] = "white"
                elif list3[y] != "red" and list3[y] != "white":
                    list3[y] = "black"
        colourHintPegChanger(j,valList,hintSq)

#okay so the loadhintpegchecker thing to be for all complete rows.
#so
#listy = list of elements to be loaded

#this essentially changes the 'active' values in the main loop so they fit with the values in 'listy'
def loader(slot,guessList,listOfGuesses,hintSq):
    listy = makeItLoad(slot)
    
    guessList2 = listy[0]
    guessNumber = int(listy[1])
    countLimit = int(listy[2])
    start_stopwatch_time = float(listy[3])
    start_stopwatch_time = start_stopwatch_time - 1.00

    winningGuess = listy[4]
    listOfGuessesT = listMaker10()

    guessList = guessListChanger(guessList2,guessList)
    loadUpdater(guessList,listOfGuesses,countLimit,guessNumber)

    loadHintPegChecker(guessList,winningGuess,guessNumber,hintSq,countLimit)
    saveLoad = False
    changed = True
    return guessList, winningGuess, guessNumber, hintSq, countLimit,saveLoad, changed, start_stopwatch_time

#various variables

saveLoad = False
saved_time = 0
start_stopwatch_time = 0
stopwatch.reset()
stopwatch.stop()
instructions = False
mainMenu = True

inputBox = inputBox()

instructionsList = ["The computer has generated a sequence of 4 colours.",
                "Your job is to guess it in the lowest time possible.",
                "After you guess, you get 4 hint pegs.",
                "A white peg means the right colour, but wrong place.",
                "A red peg means the right colour and right place.",
                "A black peg means the wrong colour and wrong place.",
                "You have 10 guesses to get it right.",
                "Race against the clock in the logic game of the century!"]

text = ""
text2 = ""
tempScore = 20200
inputting = False
charLimit = 0
nameEntered = False
savedHighScore = False
playing = False
playingPaused = False


while running:
    #listOfGuesses = listMaker10()
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.KEYDOWN:
            if inputting == True:
                if charLimit == 20:
                    inputting = False
                    nameEntered = True
                if event.key == pygame.K_RETURN:
                    nameEntered = True
                    inputting = False
                elif event.key == pygame.K_BACKSPACE:
                    text = text[:-1]
                else:
                    text += event.unicode
            
        if event.type == pygame.MOUSEBUTTONUP:
            pos = pygame.mouse.get_pos()
            for y in listOfButtons:
                if y.rect.collidepoint(pos):
                    function = y.text
                    if function == "Start":
                        stopwatch.start()
                        y.text = "Pause"
                        #UNCOMMENT THIS FOR EASY TESTING!
                        #print(winningGuess)
                        paused = False
                        saveLoad = False
                        mainMenu = False
                        instructions = False
                        win = False
                    elif function == "Pause":
                        stopwatch.stop()
                        y.text = "Start"
                        paused = True
                    elif function == "Main Menu":
                        listOfButtons[0].text = "Quit"
                        listOfButtons[1].text = "Start"
                        winLostSeq = False
                        lastGuessWin = False
                        win = False
                        lose = False
                        leaderboardEntered = False
                        paused = True
                        #reset
                        winningGuess = generateRandomColourSequence()
                        stopwatch.reset()
                        start_stopwatch_time = 0
                        guessList = [[],[],[],[],[],[],[],[],[],[]]
                        for x in listOfGuesses:
                            for y in x:
                                if y.colour != "white":
                                    y.colour = "white"
                                    y.rgb = (255,255,255)

                        for x in hintSq:
                            for y in x:
                                y.colour = "black"
                                y.rgb = (0,0,0)

                        guessNumber = 0
                        countLimit = 0
                        mainMenu = True
                        saveLoad = False
                        instructions = False
                    elif function == "Quit":
                        running = False

                    elif function == "Instructions":
                        instructions = True
                        saveLoad = False
                        mainMenu = False
            temp = buttonSaveLoad
            if temp.rect.collidepoint(pos) and paused == True:
                saveLoad = True
                mainMenu = False
            for x in interfacePegs:
                if x.rect.collidepoint(pos) and paused == False:
                    colour2 = x.colour
                    if guessNumber > 9:
                        break
                    else:
                        countLimit += 1
                        guessList[guessNumber].append(colour2)
                        changed = False
            for x in slotButtons:
                if x.rect.collidepoint(pos) and saveLoad == True:
                    slotty = x.text
                    slotPos = int(slotty[5])

            for x in saveLoadMiniButtons:
                if x.rect.collidepoint(pos) and saveLoad == True:
                    function = x.text
                    if function == "Save":
                        #save
                        timeinS = passed_time/1000
                        #time to be saved = real_time.strip("s",""), float
                        savey_stoppy_time = real_time.replace("s","")
                        savey_stoppy_time = float(savey_stoppy_time)
                        save_game(listOfGuesses,winningGuess,guessNumber,countLimit,slotPos,savey_stoppy_time)
                        loadVals = []
                        
                    else:
                        #load
                        stopwatch.reset()
                        #resetting values...
                        guessList = [[],[],[],[],[],[],[],[],[],[]]
                        for x in listOfGuesses:
                            for y in x:
                                if y.colour != "white":
                                    y.colour = "white"
                                    y.rgb = (255,255,255)

                        for x in hintSq:
                            for y in x:
                                y.colour = "black"
                                y.rgb = (0,0,0)
                                
                        loadVals = loader(slotPos,guessList,listOfGuesses,hintSq)

                        guessList = loadVals[0]
                        winningGuess = loadVals[1]
                        guessNumber = loadVals[2]
                        hintSq = loadVals[3]
                        countLimit = loadVals[4]
                        saveLoad = loadVals[5]
                        changed = loadVals[6]
                        start_stopwatch_time = loadVals[7]

                        
            if inputBox.rect.collidepoint(pos) and win == True:
                inputting = True
                text = ""

    #playing pause/play songs            
    if playing == False and paused == False:
        pygame.mixer.music.fadeout(500)
        pygame.mixer.music.load('song.wav')
        pygame.mixer.music.play(-1)
        playing = True
        playingPaused = False

    if paused == True and playingPaused == False:
        pygame.mixer.music.fadeout(500)
        pygame.mixer.music.load('songPaused.wav')
        pygame.mixer.music.play(-1,0,1000)
        playingPaused = True
        playing = False
        
    if countLimit == 0 and guessNumber == 0:
        listOfGuesses = listMaker10()
    elif changed == True:
        pass
    else:
        #changes when guessing
        listOfGuesses = colourOfEnteredGuessChanger(countLimit,guessNumber+1,colour2,listOfGuesses)
        changed = True
        
    if countLimit == 4:
        win = checkForWin(guessList[guessNumber],winningGuess)
        #check for winning sequence
        #if true do win
        if win == False:
            #hint pegs changer after all 4 guessed
            list3 = ["","","",""]
            valList = list3
            '''for x in range(4):
                thing = guessList[guessNumber]
                theColour = thing[x]
                thePosition = x
                theTrue =  winningGuess
                val = PegValidity(theColour,thePosition,theTrue)
                print(val)
                valList.append(val)'''
            list1 = guessList[guessNumber]
            list2 = winningGuess
            
            for x in range(4):
                for y in range(4):
                    pos1 = y
                    pos2 = x
                    if list1[y] == list2[x] and y == x:
                        list3[y] = "red"
                    elif list1[y] == list2[x] and y != x:
                        if list3[y] != "red":
                            list3[y] = "white"
                    elif list3[y] != "red" and list3[y] != "white":
                        list3[y] = "black"
                    
            colourHintPegChanger(guessNumber,valList,hintSq)    
            pass

            
            
        countLimit = 0
        guessNumber += 1
    if guessNumber >= 10 and win == False:
        win = True
        lose = True
        running = True
    elif guessNumber >= 10 and win == True and lastGuessWin == False:
        lastGuessWin = True
        win = True
        lose = False
            

    screen.fill((0,0,0))
    count = 0
    
    #hint pegs render
    for x in hintSq:
        for y in x:
            pygame.draw.rect(screen,y.rgb,y.rect)
    for x in interfacePegs:
        y = colourToRgb(x.colour)
        pygame.draw.rect(screen,y,x.rect)
        count = count+1
    for x in range(0,len(listOfGuesses)):
        for y in listOfGuesses[x]:
            pygame.draw.rect(screen,y.rgb,y.rect)
    #paused menu        
    if paused == True:
        screen.fill((0,0,0))
        pausedText1 = font.render("Paused",True,font_color)
        pausedText2 = font.render("No peeking ;)",True,font_color)
        screen.blit(pausedText1,(268,273))
        screen.blit(pausedText2,(240,305))
        pygame.draw.rect(screen,buttonSaveLoad.colourBig,buttonSaveLoad.rect)
        pygame.draw.rect(screen,buttonSaveLoad.colourSmall,buttonSaveLoad.smallerRect)
        textY = fontSmaller.render(buttonSaveLoad.text,True,fontSmallerColour)
        screen.blit(textY,buttonSaveLoad.textPos)

    #saveload
    if saveLoad == True:
        screen.fill((0,0,0))
        saveloadText1 = "Save or Load?"
        message_display(saveloadText1,300,50,40)

        #slotbuttons render
        for x in slotButtons:
            button = x
            pygame.draw.rect(screen,button.colourBig,button.rect)
            pygame.draw.rect(screen,button.colourSmall,button.smallerRect)
            tempPos = button.textPos
            pos1 = tempPos[0]
            pos2 = tempPos[1]
            message_display(button.text,pos1,pos2,button.fontSize)

        #mini save/load render    
        if slotPos > 0:
            multiplier = 0
            saveLoadMiniButtons = [miniSave,miniLoad]
            for x in saveLoadMiniButtons:
                button = x
                if slotPos == 2:
                    multiplier = 100 + multiplier
                elif slotPos == 3:
                    multiplier = 200 + multiplier
                else:
                    pass

                button.rect = pygame.Rect(400,156+multiplier,140,35)
                button.smallerRect = pygame.Rect(400+5,156+5+multiplier,130,25)
                button.textPos = (470,174+multiplier)
                
                pygame.draw.rect(screen,button.colourBig,button.rect)
                pygame.draw.rect(screen,button.colourSmall,button.smallerRect)
                tempPos = button.textPos
                pos1 = tempPos[0]
                pos2 = tempPos[1]
                message_display(button.text,pos1,pos2,button.fontSize)
                multiplier = 50


    #instructions
    if instructions == True:
        screen.fill((0,0,0))
        paragraph = 100      
        message_display("INSTRUCTIONS",300,50,40)
        for x in instructionsList:
            message_display(x,300,paragraph,20)
            paragraph += 50
        for x in listOfButtons:
            if x.text == "Instructions":
                x.text = "Main Menu"
            pygame.draw.rect(screen,x.colourBig,x.rect)
            pygame.draw.rect(screen,x.colourSmall,x.smallerRect)
            textX = fontSmaller.render(x.text,True,fontSmallerColour)
            screen.blit(textX,x.textPos)

    #main menu
    if mainMenu == True:
        screen.fill((0,0,0))
        for y in listOfButtons:
            function = y.text
            if function == "Main Menu":
                y.text = "Instructions"
                y.textPos = (490,640-100)
        screen.blit(banner,(-50,0))
        message_display("Battle against the clock!",320,150,20)
        #message_display("Welcome... to Mastermind!",300,300,20)
        message_display("Leaderboard:",320,260,40)
        paragraph = 310
        load_leaderboard()
        for leader in leaderboard:
            message_display(leader,320,paragraph,30)
            paragraph += 50
        pygame.draw.rect(screen,buttonSaveLoad.colourBig,buttonSaveLoad.rect)
        pygame.draw.rect(screen,buttonSaveLoad.colourSmall,buttonSaveLoad.smallerRect)
        textY = fontSmaller.render(buttonSaveLoad.text,True,fontSmallerColour)
        screen.blit(textY,buttonSaveLoad.textPos)

    if mainMenu == False:
        for y in listOfButtons:
            function = y.text
            if function == "Instructions":
                y.text = "Main Menu"

                
    #score calculator
    #win just really means 'game over' in this context
    if win == True:
        text = ""
        paused = True
        stopwatch.stop()
        screen.fill((0,0,0))
        stoppy = str(stopwatch)
        stoppy = stoppy.replace("s","")
        stoppy = float(stoppy)
        stoppy = stoppy + start_stopwatch_time
        stoppy = round(stoppy,2)
        score = (1/guessNumber) * (1/stoppy) * 100000
        score = round(score)
        screen.fill((0,0,0))
        tempScore = score
        score = tempScore
        if lose == True and lastGuessWin == False:
            #print("score should be 0")
            tempScore = 0
        leaderboardEntered = check_last_score(tempScore)
        #print(tempScore)
        if leaderboardEntered == False:
            win = False
            #if win is false it can't go to the win screen, so it goes to the other screen for games that are over
            winLostSeq = True
        else:
            win = True
            pygame.mixer.music.fadeout(500)
            win_sound = pygame.mixer.Sound("victory.wav")
            pygame.mixer.Sound.play(win_sound)
            
    #no high score, but game completed
    if winLostSeq == True:
        screen.fill((0,0,0))
        listOfButtons[1].text = ""
        listOfButtons[0].text = ""
        message_display("You didn't get a high score this time...",300,50,30)
        message_display("Better luck next time!",300,150,30)
        message_display("Leaderboard: ",300,200,30)
        text1 = "Score: "+ str(tempScore)
        message_display(text1,300,250,40)
        paragraph = 320
        load_leaderboard()
        i = 1
        for leader in leaderboard:
            message = str(i)+") "+leader
            message_display(message,300,paragraph,30)
            paragraph += 50
            i += 1
        text2 = "Press Main Menu to load a save or play again!"
        message_display(text2,300,470,20)        

    #winning screen
    #this just worked better as a loop....
    #it's probably to do with the input box somehow
        
    while win == True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                high_score = False
                win = False
                running = False
            if event.type == pygame.MOUSEBUTTONUP:
                pos = pygame.mouse.get_pos()
                for y in listOfButtons:
                    if y.rect.collidepoint(pos):
                        function = y.text
                        if function == "Main Menu":
                            #unfortunately this just does basically all of the main menu stuff from the main loop
                            listOfButtons[1].text = "Start"

                            winLostSeq = False
                            lastGuessWin = False
                            win = False
                            lose = False
                            leaderboardEntered = False
                            savedHighScore = False
                            nameEntered = False
                            winLostSeq = False
                            win = False
                            leaderboardEntered = False
                            paused = True
                            #reset
                            winningGuess = generateRandomColourSequence()
                            stopwatch.reset()
                            start_stopwatch_time = 0
                            guessList = [[],[],[],[],[],[],[],[],[],[]]
                            for x in listOfGuesses:
                                for y in x:
                                    if y.colour != "white":
                                        y.colour = "white"
                                        y.rgb = (255,255,255)

                            for x in hintSq:
                                for y in x:
                                    y.colour = "black"
                                    y.rgb = (0,0,0)

                            guessNumber = 0
                            countLimit = 0
                            mainMenu = True
                            saveLoad = False
                            instructions = False    
                        elif function == "Quit":
                            running = False
                            win = False
                            break
                if inputBox.rect.collidepoint(pos):
                    inputting = True
                    text = ""
            #this lets you input your own name by taking the ascii input from your keyboard & appending it to a string
            #once done this string becomes your name
            if event.type == pygame.KEYDOWN:
                if inputting == True:
                    if charLimit == 20:
                        inputting = False
                        nameEntered = True
                    if event.key == pygame.K_RETURN:
                        nameEntered = True
                        inputting = False
                    elif event.key == pygame.K_BACKSPACE:
                        text = text[:-1]
                    else:
                        text += event.unicode
                        charLimit += 1

        if mainMenu == True or instructions == True or saveLoad == True:
            paused = True
                
        screen.fill((0,0,0))
        
        message_display("High score!",300,50,40)
        message_display("Enter name (up to 20 characters)",300,100,30)
        if nameEntered == True:
            #just in case there's no text
            if text == "" or text == "Asuka" and savedHighScore == False:
                text = "Asuka"
                save_high_score(tempScore,text)
                savedHighScore = True
                
            if text == "Asuka" or text == "":
                message_display("No name inputted. Using name 'Asuka'.",300,130,15)
                
            if savedHighScore == False:
                save_high_score(tempScore,text)
                savedHighScore = True
            
            paragraph = 300
            load_leaderboard()
            i = 1
            for leader in leaderboard:
                message = str(i)+") "+leader
                message_display(message,300,paragraph,30)
                paragraph += 50
                i += 1
            text2 = "Press Main Menu to load a save or play again!"
            message_display(text2,300,470,20)
            
        pygame.draw.rect(screen,inputBox.colourBig,inputBox.rect)
        pygame.draw.rect(screen,inputBox.colourSmall,inputBox.smallerRect)
        message_display(text,305,180,30)

        
        #buttons
        for x in listOfButtons:
            function = x.text
            if function == "Start" or function == "Pause":
                pass
            else:
                pygame.draw.rect(screen,x.colourBig,x.rect)
                pygame.draw.rect(screen,x.colourSmall,x.smallerRect)
                textX = fontSmaller.render(x.text,True,fontSmallerColour)
                screen.blit(textX,x.textPos)
        
        pygame.display.flip()
        clock.tick(60)        
        
    #buttons render
    for x in listOfButtons:
        pygame.draw.rect(screen,x.colourBig,x.rect)
        pygame.draw.rect(screen,x.colourSmall,x.smallerRect)
        textX = fontSmaller.render(x.text,True,fontSmallerColour)
        screen.blit(textX,x.textPos)
    #pygame.draw.rect(screen,buttonQuit.colourBig,buttonQuit.rect)
    #pygame.draw.rect(screen,buttonQuit.colourSmall,buttonQuit.smallerRect)


                     
    #timer render

    string_stopwatch = str(stopwatch)

    #basically, this timer runs in milliseconds and microseconds which is not relevant to the player at all
    #so this stops the timer appearing before it's reacher 1.00seconds

    #start_stopwatch_time is a value in seconds that lets you start from another point in time
    
    if string_stopwatch[-1] == "s" and string_stopwatch[-2] != "m" and string_stopwatch[-2] != "μ":
        
        string_stopwatch = string_stopwatch.replace("s","")
        string_stopwatch_float = float(string_stopwatch)
        real_time = string_stopwatch_float + start_stopwatch_time
        real_time = round(real_time,2)
        real_time = str(real_time) + "s"


    else:
        real_time = "0s"        

    if mainMenu == False and instructions == False and win == False and winLostSeq == False:
        text = font.render(real_time,True,font_color)
        screen.blit(text,(540,680))
    
    pygame.display.flip()
    clock.tick(60)
        
pygame.quit()
